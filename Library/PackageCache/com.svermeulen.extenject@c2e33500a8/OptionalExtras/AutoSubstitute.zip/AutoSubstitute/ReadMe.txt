Instructions:

After extraction of AutoSubstitute.zip you will a folder named 'AutoSubstitute'.
It contains the NSubstitute library and the ZenjectNSubstituteExtension class.

Just drop the AutoSubstitute folder into:
Zenject/OptionalExtras/TestFramework/Editor/

And you're good to go!

Note:
The provided library of NSubstitute is v2.0.3.0 for .Net v4.5.
This version is known to work wit Unity3D 2017, 2018 and 2019.
You may need to set your project's scripting runtime settings to '.Net 4.x'.
